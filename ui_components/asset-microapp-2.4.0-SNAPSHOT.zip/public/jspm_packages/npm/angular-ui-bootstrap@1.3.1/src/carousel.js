/* */ 
module.exports = require('./carousel/index');
