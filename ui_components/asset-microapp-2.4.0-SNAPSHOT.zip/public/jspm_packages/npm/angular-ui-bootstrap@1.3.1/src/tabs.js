/* */ 
module.exports = require('./tabs/index');
