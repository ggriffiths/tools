/* */ 
module.exports = require('./typeahead/index');
