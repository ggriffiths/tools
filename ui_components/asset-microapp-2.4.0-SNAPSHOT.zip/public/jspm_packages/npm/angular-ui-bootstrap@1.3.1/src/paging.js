/* */ 
module.exports = require('./paging/index');
