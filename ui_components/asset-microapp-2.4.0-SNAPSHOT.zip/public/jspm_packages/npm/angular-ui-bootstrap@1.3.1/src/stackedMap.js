/* */ 
module.exports = require('./stackedMap/index');
