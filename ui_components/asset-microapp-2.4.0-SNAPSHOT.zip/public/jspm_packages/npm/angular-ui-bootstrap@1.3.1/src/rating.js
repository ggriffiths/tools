/* */ 
module.exports = require('./rating/index');
