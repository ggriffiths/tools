/* */ 
module.exports = require('./isClass/index');
