/* */ 
module.exports = { "default": require("core-js/library/fn/array/entries"), __esModule: true };